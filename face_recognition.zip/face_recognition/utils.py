import cv2

def load_cascade(cascade_path):
    return cv2.CascadeClassifier(cascade_path)

def resize_image(img, size=(200, 200)):
    return cv2.resize(img, size)
