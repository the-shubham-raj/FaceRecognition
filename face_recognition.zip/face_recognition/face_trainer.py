import cv2
import os
import numpy as np

class FaceTrainer:
    def __init__(self, dataset_path="dataset", model_path="trainer.yml"):
        self.dataset_path = dataset_path
        self.model_path = model_path
        self.face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
        self.recognizer = cv2.face.LBPHFaceRecognizer_create()

    def collect_faces(self, user_id, samples=30):
        cap = cv2.VideoCapture(0)
        count = 0
        os.makedirs(self.dataset_path, exist_ok=True)

        while True:
            ret, img = cap.read()
            if not ret:
                break

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)

            for (x, y, w, h) in faces:
                face_img = gray[y:y+h, x:x+w]
                cv2.imwrite(f"{self.dataset_path}/User.{user_id}.{count}.jpg", face_img)
                count += 1

                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 0), 2)
                cv2.imshow("Collecting Faces", img)

            if cv2.waitKey(1) & 0xFF == 27 or count >= samples:
                break

        cap.release()
        cv2.destroyAllWindows()
        print(f"Collected {count} images for User ID: {user_id}")

    def train_faces(self):
        images, labels = [], []
        for filename in os.listdir(self.dataset_path):
            if filename.endswith(".jpg"):
                label = int(filename.split(".")[1])
                img_path = os.path.join(self.dataset_path, filename)
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                images.append(img)
                labels.append(label)

        self.recognizer.train(images, np.array(labels))
        self.recognizer.save(self.model_path)
        print(f"Training complete. Model saved as {self.model_path}")
